-- MySQL dump 10.13  Distrib 5.7.41, for Linux (x86_64)
--
-- Host: mysql    Database: medic
-- ------------------------------------------------------
-- Server version	5.7.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `medic`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `medic` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `medic`;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `dni` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `day_of_birth` date DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `rol` int(11) NOT NULL DEFAULT '3',
  PRIMARY KEY (`id_admin`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `dni` (`dni`),
  KEY `gender` (`gender`),
  CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`gender`) REFERENCES `genders` (`gender_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,123456,'CHRIS','LP',1,'2023-09-20','admin@mail.com','1144246350',1,'2023-09-19 03:19:13','e10adc3949ba59abbe56e057f20f883e',3);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `appodate` date DEFAULT NULL,
  `apponum` int(11) DEFAULT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`scheduleid`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id_patient`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (2,1,117,'2023-10-30',45),(4,2,81,'2023-10-30',45),(5,2,81,'2023-10-30',45),(7,50,81,'2023-10-30',63),(8,50,81,'2023-10-30',63);
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audits`
--

DROP TABLE IF EXISTS `audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audits` (
  `id_audit` int(11) NOT NULL AUTO_INCREMENT,
  `id_clinic_history` int(11) NOT NULL,
  `id_patient` int(11) DEFAULT NULL,
  `id_medic` int(11) DEFAULT NULL,
  `clinic_history_old` text CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci,
  `clinic_history_new` text CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci,
  `symptoms_old_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `symptoms_new_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `audits_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_audit`),
  KEY `audits_ibfk_1` (`id_medic`),
  KEY `audits_ibfk_2` (`id_patient`),
  KEY `audits_ibfk_3` (`id_clinic_history`),
  CONSTRAINT `audits_ibfk_1` FOREIGN KEY (`id_medic`) REFERENCES `medics` (`id_medic`),
  CONSTRAINT `audits_ibfk_2` FOREIGN KEY (`id_patient`) REFERENCES `patients` (`id_patient`),
  CONSTRAINT `audits_ibfk_3` FOREIGN KEY (`id_clinic_history`) REFERENCES `clinic_history` (`id_clinic_history`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COMMENT='Tabla para registrar cambio de Historia Clinica';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audits`
--

LOCK TABLES `audits` WRITE;
/*!40000 ALTER TABLE `audits` DISABLE KEYS */;
INSERT INTO `audits` VALUES (127,9,78,3,'asd','asdas',NULL,NULL,'2023-12-06 17:15:47'),(128,9,78,3,'asdas','asdas que va a ser',NULL,NULL,'2023-12-06 17:15:58');
/*!40000 ALTER TABLE `audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clinic_history`
--

DROP TABLE IF EXISTS `clinic_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clinic_history` (
  `id_clinic_history` int(11) NOT NULL AUTO_INCREMENT,
  `clinic_history` text NOT NULL,
  `id_patient` int(11) NOT NULL,
  `id_medic` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_clinic_history`),
  KEY `clinic_history_ibfk_1` (`id_medic`),
  KEY `clinic_history_ibfk_2` (`id_patient`),
  CONSTRAINT `clinic_history_ibfk_1` FOREIGN KEY (`id_medic`) REFERENCES `medics` (`id_medic`),
  CONSTRAINT `clinic_history_ibfk_2` FOREIGN KEY (`id_patient`) REFERENCES `patients` (`id_patient`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='Tabla para registrar cambio de historia clinica';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinic_history`
--

LOCK TABLES `clinic_history` WRITE;
/*!40000 ALTER TABLE `clinic_history` DISABLE KEYS */;
INSERT INTO `clinic_history` VALUES (9,'asdas que va a ser',78,3,'2023-12-06 19:57:34');
/*!40000 ALTER TABLE `clinic_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`medic`@`%`*/ /*!50003 TRIGGER `clinic_history` BEFORE UPDATE ON `clinic_history` FOR EACH ROW BEGIN 
    DECLARE clinic_history_old text;
    DECLARE clinic_history_new text; 
    DECLARE id_clinic_history INT DEFAULT 0;
    DECLARE id_medic INT DEFAULT 0;
    DECLARE id_patient INT DEFAULT 0;
SET clinic_history_old = OLD.clinic_history; 
SET clinic_history_new = NEW.clinic_history;
SET id_medic = OLD.id_medic;
SET id_patient = OLD.id_patient;
SET id_clinic_history = OLD.id_clinic_history;
IF clinic_history_old != clinic_history_new THEN
INSERT INTO audits ( audits.id_clinic_history, audits.id_patient, audits.id_medic, audits.clinic_history_old, audits.clinic_history_new) VALUES ( id_clinic_history, id_patient, id_medic, clinic_history_old, clinic_history_new);
END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `clinic_history_symptoms`
--

DROP TABLE IF EXISTS `clinic_history_symptoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clinic_history_symptoms` (
  `id_clinic_history_symptom` int(11) NOT NULL AUTO_INCREMENT,
  `id_clinic_history` int(11) DEFAULT NULL,
  `code_symptom` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`id_clinic_history_symptom`),
  KEY `id_clinic_history` (`id_clinic_history`),
  KEY `code_symptom` (`code_symptom`),
  CONSTRAINT `clinic_history_symptoms_ibfk_1` FOREIGN KEY (`id_clinic_history`) REFERENCES `clinic_history` (`id_clinic_history`),
  CONSTRAINT `clinic_history_symptoms_ibfk_2` FOREIGN KEY (`code_symptom`) REFERENCES `symptoms` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinic_history_symptoms`
--

LOCK TABLES `clinic_history_symptoms` WRITE;
/*!40000 ALTER TABLE `clinic_history_symptoms` DISABLE KEYS */;
INSERT INTO `clinic_history_symptoms` VALUES (1,5,'S1'),(2,5,'S2');
/*!40000 ALTER TABLE `clinic_history_symptoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genders`
--

DROP TABLE IF EXISTS `genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genders` (
  `gender_id` tinyint(4) NOT NULL,
  `gender_name` varchar(255) NOT NULL,
  PRIMARY KEY (`gender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genders`
--

LOCK TABLES `genders` WRITE;
/*!40000 ALTER TABLE `genders` DISABLE KEYS */;
INSERT INTO `genders` VALUES (1,'Masculino'),(2,'Femenino'),(3,'Otro');
/*!40000 ALTER TABLE `genders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listado`
--

DROP TABLE IF EXISTS `listado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listado` (
  `matricul` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `day_of_birth` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `specialty` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listado`
--

LOCK TABLES `listado` WRITE;
/*!40000 ALTER TABLE `listado` DISABLE KEYS */;
/*!40000 ALTER TABLE `listado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medics`
--

DROP TABLE IF EXISTS `medics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medics` (
  `id_medic` int(11) NOT NULL AUTO_INCREMENT,
  `matricul_medic` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `name_medic` varchar(50) COLLATE utf8mb4_czech_ci NOT NULL,
  `surname_medic` varchar(50) COLLATE utf8mb4_czech_ci NOT NULL,
  `gender_medic` tinyint(1) NOT NULL,
  `day_of_birth_medic` date NOT NULL,
  `email_medic` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `phone_medic` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `specialty_id` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rol` int(11) NOT NULL DEFAULT '2',
  `password_medic` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `availability` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`id_medic`),
  UNIQUE KEY `matricul_medic` (`matricul_medic`),
  UNIQUE KEY `uk_matricul_medic` (`matricul_medic`),
  UNIQUE KEY `uk_email_medic` (`email_medic`),
  KEY `gender_medic` (`gender_medic`),
  KEY `specialty_medic` (`specialty_id`),
  CONSTRAINT `medics_ibfk_1` FOREIGN KEY (`gender_medic`) REFERENCES `genders` (`gender_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medics`
--

LOCK TABLES `medics` WRITE;
/*!40000 ALTER TABLE `medics` DISABLE KEYS */;
INSERT INTO `medics` VALUES (1,'123456','chris','lp',1,'1994-09-24','medico@mail.com','123456',7,1,'2023-10-12 15:47:57',2,'e10adc3949ba59abbe56e057f20f883e','De lunes a viernes de 08:00hs. a 17:00hs.'),(2,'323213123','Juan','Perez',2,'1988-08-02','perez@admin.com','434132412343',10,1,'2023-10-15 15:23:02',2,'$2y$10$c1k8m.IMe5x/ZiKYsP8INuocu9YUi6yoekFxfLi3aaOhRpN4Qm55u','lunes a viernes de 15 hs a 19 hs'),(3,'123123','fabian hola','ñlopez',1,'1994-09-24','fabian@mail.com','1144246350',1,1,'2023-10-19 18:36:52',2,'e10adc3949ba59abbe56e057f20f883e','lunes a viernes de 15 hs a 19 hs'),(4,'456789','Evelyn','Pereyra',2,'1993-01-29','eve@mail.com','456789123',3,1,'2023-10-24 23:43:53',2,'','lunes a viernes de 15 hs a 19 hs'),(5,'456456','jorge','lopez',2,'1994-09-24','asdasdasdas@mail.com','1144246350',4,1,'2023-10-26 21:13:31',2,'e10adc3949ba59abbe56e057f20f883e','lunes a viernes de 15 hs a 19 hs');
/*!40000 ALTER TABLE `medics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `id_patient` int(11) NOT NULL AUTO_INCREMENT,
  `dni` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `day_of_birth` date DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `rol` int(11) NOT NULL DEFAULT '1',
  `id_clinic_history` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_patient`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `dni` (`dni`),
  UNIQUE KEY `id_clinic_history` (`id_clinic_history`) USING BTREE,
  UNIQUE KEY `id_clinic_history_2` (`id_clinic_history`),
  KEY `gender` (`gender`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (78,123456,'carlos','poco',NULL,'2023-09-20','Hola@hola.com','543345',NULL,'2023-09-17 08:48:12','asdasd',1,8),(83,324234,'seva','moco',NULL,NULL,'chris@mail.com','678678',NULL,'2023-09-19 04:51:16','asdasd',1,NULL),(96,NULL,NULL,NULL,NULL,NULL,'chrisasdasd@mail.com',NULL,NULL,'2023-10-12 03:45:50','asdasd',1,NULL),(117,38458333,'Christian',NULL,NULL,NULL,'chrisk_19_94@hotmail.com','1144246350',NULL,'2023-10-29 17:00:13','e10adc3949ba59abbe56e057f20f883e',1,NULL),(118,NULL,NULL,NULL,NULL,NULL,'new_chriss@hotmail.com.ar',NULL,NULL,'2023-11-09 21:39:45','e10adc3949ba59abbe56e057f20f883e',1,NULL);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `id_medic` int(11) NOT NULL,
  `scheduledate` date NOT NULL,
  `scheduletime` time NOT NULL,
  `nop` int(11) NOT NULL,
  PRIMARY KEY (`scheduleid`),
  KEY `id_medic` (`id_medic`),
  CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`id_medic`) REFERENCES `medics` (`id_medic`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,'cardiologia',4,'2023-10-30','08:00:00',0),(2,'cardiologia',4,'2023-10-30','09:00:00',-1),(3,'cardiologia',4,'2023-10-30','10:00:00',0),(4,'cardiologia',4,'2023-10-30','11:00:00',0),(5,'cardiologia',4,'2023-10-30','12:00:00',1),(6,'cardiologia',4,'2023-10-30','13:00:00',1),(7,'cardiologia',4,'2023-10-30','14:00:00',1),(8,'cardiologia',4,'2023-10-30','15:00:00',1),(9,'cardiologia',4,'2023-10-30','16:00:00',1),(10,'cardiologia',4,'2023-10-31','08:00:00',1),(11,'cardiologia',4,'2023-10-31','09:00:00',1),(12,'cardiologia',4,'2023-10-31','10:00:00',1),(13,'cardiologia',4,'2023-10-31','11:00:00',1),(14,'cardiologia',4,'2023-10-31','12:00:00',1),(15,'cardiologia',4,'2023-10-31','13:00:00',1),(16,'cardiologia',4,'2023-10-31','14:00:00',1),(17,'cardiologia',4,'2023-10-31','15:00:00',1),(18,'cardiologia',4,'2023-10-31','16:00:00',1),(19,'cardiologia',4,'2023-11-01','08:00:00',1),(20,'cardiologia',4,'2023-11-01','09:00:00',1),(21,'cardiologia',4,'2023-11-01','10:00:00',1),(22,'cardiologia',4,'2023-11-01','11:00:00',1),(23,'cardiologia',4,'2023-11-01','12:00:00',1),(24,'cardiologia',4,'2023-11-01','13:00:00',1),(25,'cardiologia',4,'2023-11-01','14:00:00',1),(26,'cardiologia',4,'2023-11-01','15:00:00',1),(27,'cardiologia',4,'2023-11-01','16:00:00',1),(28,'cardiologia',4,'2023-11-02','08:00:00',1),(29,'cardiologia',4,'2023-11-02','09:00:00',1),(30,'cardiologia',4,'2023-11-02','10:00:00',1),(31,'cardiologia',4,'2023-11-02','11:00:00',1),(32,'cardiologia',4,'2023-11-02','12:00:00',1),(33,'cardiologia',4,'2023-11-02','13:00:00',1),(34,'cardiologia',4,'2023-11-02','14:00:00',1),(35,'cardiologia',4,'2023-11-02','15:00:00',1),(36,'cardiologia',4,'2023-11-02','16:00:00',1),(37,'cardiologia',4,'2023-11-03','08:00:00',1),(38,'cardiologia',4,'2023-11-03','09:00:00',1),(39,'cardiologia',4,'2023-11-03','10:00:00',1),(40,'cardiologia',4,'2023-11-03','11:00:00',1),(41,'cardiologia',4,'2023-11-03','12:00:00',1),(42,'cardiologia',4,'2023-11-03','13:00:00',1),(43,'cardiologia',4,'2023-11-03','14:00:00',1),(44,'cardiologia',4,'2023-11-03','15:00:00',1),(45,'cardiologia',4,'2023-11-03','16:00:00',1),(46,'radiologia',1,'2023-10-30','08:00:00',0),(47,'radiologia',1,'2023-10-30','09:00:00',0),(48,'radiologia',1,'2023-10-30','10:00:00',0),(49,'radiologia',1,'2023-10-30','11:00:00',1),(50,'radiologia',1,'2023-10-30','12:00:00',-1),(51,'radiologia',1,'2023-10-30','13:00:00',1),(52,'radiologia',1,'2023-10-30','14:00:00',1),(53,'radiologia',1,'2023-10-30','15:00:00',1),(54,'radiologia',1,'2023-10-30','16:00:00',1),(55,'radiologia',1,'2023-10-31','08:00:00',1),(56,'radiologia',1,'2023-10-31','09:00:00',1),(57,'radiologia',1,'2023-10-31','10:00:00',1),(58,'radiologia',1,'2023-10-31','11:00:00',1),(59,'radiologia',1,'2023-10-31','12:00:00',1),(60,'radiologia',1,'2023-10-31','13:00:00',1),(61,'radiologia',1,'2023-10-31','14:00:00',1),(62,'radiologia',1,'2023-10-31','15:00:00',1),(63,'radiologia',1,'2023-10-31','16:00:00',1),(64,'prueba',4,'2023-12-05','08:00:00',1),(65,'prueba',4,'2023-12-05','09:00:00',1),(66,'prueba',4,'2023-12-05','10:00:00',1),(67,'prueba',4,'2023-12-05','11:00:00',1),(68,'prueba',4,'2023-12-05','12:00:00',1),(69,'prueba',4,'2023-12-05','13:00:00',1),(70,'prueba',4,'2023-12-05','14:00:00',1),(71,'prueba',4,'2023-12-05','15:00:00',1),(72,'prueba',4,'2023-12-05','16:00:00',1),(73,'prueba',4,'2023-12-06','08:00:00',1),(74,'prueba',4,'2023-12-06','09:00:00',1),(75,'prueba',4,'2023-12-06','10:00:00',1),(76,'prueba',4,'2023-12-06','11:00:00',1),(77,'prueba',4,'2023-12-06','12:00:00',1),(78,'prueba',4,'2023-12-06','13:00:00',1),(79,'prueba',4,'2023-12-06','14:00:00',1),(80,'prueba',4,'2023-12-06','15:00:00',1),(81,'prueba',4,'2023-12-06','16:00:00',1),(82,'prueba',4,'2023-12-07','08:00:00',1),(83,'prueba',4,'2023-12-07','09:00:00',1),(84,'prueba',4,'2023-12-07','10:00:00',1),(85,'prueba',4,'2023-12-07','11:00:00',1),(86,'prueba',4,'2023-12-07','12:00:00',1),(87,'prueba',4,'2023-12-07','13:00:00',1),(88,'prueba',4,'2023-12-07','14:00:00',1),(89,'prueba',4,'2023-12-07','15:00:00',1),(90,'prueba',4,'2023-12-07','16:00:00',1),(91,'prueba',4,'2023-12-08','08:00:00',1),(92,'prueba',4,'2023-12-08','09:00:00',1),(93,'prueba',4,'2023-12-08','10:00:00',1),(94,'prueba',4,'2023-12-08','11:00:00',1),(95,'prueba',4,'2023-12-08','12:00:00',1),(96,'prueba',4,'2023-12-08','13:00:00',1),(97,'prueba',4,'2023-12-08','14:00:00',1),(98,'prueba',4,'2023-12-08','15:00:00',1),(99,'prueba',4,'2023-12-08','16:00:00',1);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialties`
--

DROP TABLE IF EXISTS `specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specialties` (
  `specialty_id` int(11) NOT NULL AUTO_INCREMENT,
  `specialty_name` varchar(255) NOT NULL,
  PRIMARY KEY (`specialty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialties`
--

LOCK TABLES `specialties` WRITE;
/*!40000 ALTER TABLE `specialties` DISABLE KEYS */;
INSERT INTO `specialties` VALUES (1,'Clinico'),(2,'Cardiologo'),(3,'Traumatologo'),(4,'Radiologo'),(5,'Ginecologo'),(6,'Infectologo'),(7,'Pediatria'),(8,'Oncologia'),(9,'porongologo');
/*!40000 ALTER TABLE `specialties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `state_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(255) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'Activo'),(2,'Inactivo');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `symptoms`
--

DROP TABLE IF EXISTS `symptoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symptoms` (
  `code` varchar(10) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symptoms`
--

LOCK TABLES `symptoms` WRITE;
/*!40000 ALTER TABLE `symptoms` DISABLE KEYS */;
INSERT INTO `symptoms` VALUES ('S1','Dolor de cabeza'),('S10','Dificultad para respirar'),('S11','Picazón en la piel'),('S12','Congestión nasal'),('S13','Dolor en el pecho'),('S14','Vómitos'),('S15','Diarrea'),('S16','Escalofríos'),('S17','Sensación de ardor al orinar'),('S18','Sangrado nasal'),('S19','Dolor muscular'),('S2','Fiebre'),('S20','Dolor en los ojos'),('S21','Pérdida del apetito'),('S22','Problemas de sueño'),('S23','Debilidad general'),('S24','Sensación de hormigueo'),('S25','Palpitaciones'),('S26','Inflamación de las articulaciones'),('S27','Visión borrosa'),('S28','Secreción nasal'),('S29','Ronquera'),('S3','Tos persistente'),('S30','Pérdida de peso inexplicada'),('S4','Dolor de garganta'),('S5','Fatiga'),('S6','Náuseas'),('S7','Mareos'),('S8','Dolor abdominal'),('S9','Dolor en las articulaciones');
/*!40000 ALTER TABLE `symptoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `turns`
--

DROP TABLE IF EXISTS `turns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `turns` (
  `id_turn` int(11) NOT NULL AUTO_INCREMENT,
  `FechaHora` datetime DEFAULT NULL,
  `id_medic` int(11) DEFAULT NULL,
  `Disponibilidad` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_turn`),
  KEY `id_medic` (`id_medic`) USING BTREE,
  CONSTRAINT `turns_ibfk_1` FOREIGN KEY (`id_medic`) REFERENCES `medics` (`id_medic`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turns`
--

LOCK TABLES `turns` WRITE;
/*!40000 ALTER TABLE `turns` DISABLE KEYS */;
INSERT INTO `turns` VALUES (1,'2023-09-16 08:34:52',1,1);
/*!40000 ALTER TABLE `turns` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-06 18:00:06
